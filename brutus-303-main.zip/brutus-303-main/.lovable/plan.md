

# Casino Affiliate Website — Implementation Plan

## Brand & Purpose
A trustworthy, player-friendly affiliate hub that helps users find safe casino platforms. **Not a casino** — purely reviews, comparisons, and outbound affiliate links.

---

## Pages & Sections (Single-Page Layout)

### 1. Header / Navigation
- Site logo with **lightning-energy shimmer animation** (gold glow pulse every few seconds, shimmer on hover)
- Clean sticky nav with links to sections
- Mobile hamburger menu

### 2. Hero Section
- **Headline:** "Helping players find platforms they can trust."
- **Subtitle:** Short trust signals (expert-reviewed, verified bonuses, transparent ratings)
- Minimal height so Top Casino cards are visible above the fold on desktop
- Subtle gradient background with soft glow accents

### 3. Top Casinos Section (immediately below hero)
- **Desktop:** Grid showing 3–4 casino cards visible without scrolling
- **Mobile:** Horizontal swipe carousel using Embla Carousel
- Each card includes:
  - Casino name & star rating
  - One short benefit line
  - "Visit Casino" CTA (outbound link) + "Read Review" CTA
  - Small affiliate disclosure text
- **Card effects:** Hover lift + glow border, soft glow pulse on CTA buttons
- **"Claimed Today" counter** starting at ~$10,000, incrementing slowly with realistic small amounts
- 6 sample casino entries with placeholder data

### 4. Why Trust Us
- 3 concise bullet points with icons (e.g., Expert Reviews, Verified Bonuses, Player-First Approach)
- Clean card or icon-row layout, no paragraphs

### 5. Latest Bonuses
- Compact bonus cards (casino name, bonus headline, CTA)
- 4–6 sample bonus entries
- Horizontal scroll on mobile

### 6. Safe Play Tips
- 3–5 short bullet points with icons
- Responsible gambling messaging

### 7. Footer
- Compliance disclaimer: "Independent affiliate review site. No real-money gambling or payments happen on this website. Offers are provided by third-party operators. 18+ | Gamble responsibly."
- Navigation links, 18+ badge

---

## Visual Design
- **Dark/rich theme** with vibrant gradient accents (deep purples, golds, electric blues)
- Soft shadows, glow effects, and depth throughout
- Sparkle/energy sweep on featured elements only
- Premium feel — no spammy pop-ups or aggressive animations
- All animations subtle, controlled, and mobile-friendly

## Mobile-First
- Large thumb-friendly CTA buttons
- Swipe carousels for card sections
- No large text blocks anywhere
- Smooth touch interactions and effects

## Technical Notes
- No backend needed — all static/mock data
- Embla Carousel for swipe interactions
- CSS animations + Tailwind for all effects
- Recharts not needed — simple animated counter via React state

