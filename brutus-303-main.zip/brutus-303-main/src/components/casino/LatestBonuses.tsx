import { Gift, ExternalLink, Zap, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import useEmblaCarousel from "embla-carousel-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useEffect, useState } from "react";

const bonuses = [
  { casino: "Stake Casino", headline: "200% up to $3,000", extra: "+55 Free Spins", tag: "Hot", rank: 1 },
  { casino: "BC.Game", headline: "300% Welcome", extra: "Up to $20,000", tag: "Exclusive", rank: 2 },
  { casino: "Roobet", headline: "150% First Bonus", extra: "+100 Free Spins", tag: "Popular", rank: 3 },
  { casino: "Duelbits", headline: "100% up to $500", extra: "No Wagering", tag: "Limited", rank: 4 },
  { casino: "DiamondPlay", headline: "VIP Package up to $2,000", extra: "+50 Free Spins", tag: "Premium", rank: 5 },
];

const CountdownTimer = () => {
  const [seconds, setSeconds] = useState(82146);
  useEffect(() => {
    const interval = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(interval);
  }, []);
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return (
    <span className="text-primary font-mono text-xs">
      {d > 0 && `${d}d `}{pad(h)}:{pad(m)}:{pad(s)}
    </span>
  );
};

const BonusCard = ({ bonus }: { bonus: typeof bonuses[0] }) => (
  <div className="card-casino rounded-xl border border-border bg-card p-4 flex flex-col gap-2.5 min-w-[240px]">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="text-sm font-bold text-foreground">{bonus.casino}</span>
      </div>
      <span className="text-[10px] font-semibold bg-primary/15 text-primary px-2 py-0.5 rounded-full flex items-center gap-1">
        <Zap className="h-2.5 w-2.5" /> #{bonus.rank}
      </span>
    </div>

    <div className="flex">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className="text-primary text-xs">★</span>
      ))}
    </div>

    <div>
      <p className="text-[11px] text-muted-foreground flex items-center gap-1">
        <Gift className="h-3 w-3" /> Bonus
      </p>
      <p className="text-sm font-bold text-primary">{bonus.headline}</p>
      <p className="text-xs text-muted-foreground">{bonus.extra}</p>
    </div>

    <div className="flex items-center gap-1.5 text-muted-foreground">
      <Clock className="h-3 w-3" />
      <span className="text-[11px]">Ends:</span>
      <CountdownTimer />
    </div>

    <Button
      size="sm"
      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold glow-pulse-subtle"
      asChild
    >
      <a href="#" target="_blank" rel="noopener noreferrer nofollow">
        Claim <ExternalLink className="h-3 w-3 ml-1" />
      </a>
    </Button>

    <p className="text-[9px] text-muted-foreground/40 text-center">
      We may earn a commission from partner links.
    </p>
  </div>
);

const LatestBonuses = () => {
  const isMobile = useIsMobile();
  const [emblaRef] = useEmblaCarousel({ align: "start", containScroll: "trimSnaps" });

  return (
    <section id="bonuses" className="py-10 md:py-14">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center gap-2 mb-1">
          <Zap className="h-5 w-5 text-primary" />
          <h2 className="text-2xl font-bold text-foreground">
            Hot <span className="text-primary">Bonuses</span>
          </h2>
          <span className="text-[10px] font-bold bg-destructive/20 text-destructive px-2 py-0.5 rounded-full uppercase tracking-wider">
            Limited
          </span>
        </div>
        <p className="text-center text-xs text-muted-foreground mb-6">Exclusive offers from top-rated platforms</p>

        {isMobile ? (
          <div ref={emblaRef} className="overflow-hidden -mx-4 px-4">
            <div className="flex gap-4">
              {bonuses.map((b) => (
                <div key={b.casino} className="flex-[0_0_75%]">
                  <BonusCard bonus={b} />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-4 lg:grid-cols-4 gap-4">
            {bonuses.slice(0, 4).map((b) => (
              <BonusCard key={b.casino} bonus={b} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default LatestBonuses;
